from flask import Flask, render_template, redirect, url_for, request, session, flash
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
import MySQLdb.cursors

app = Flask(__name__)
app.secret_key = 'cb09e282cd83eca19195d584407d102c2842c31d6e9854ad9a0dbf8f8f574852'

# MySQL Configurations
app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'gurupoorna2306'
app.config['MYSQL_DB'] = 'concert_booking'

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        if user and check_password_hash(user['password'], password):
            session['loggedin'] = True
            session['id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('events'))
        else:
            flash('Incorrect username or password')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO users (username, email, password) VALUES (%s, %s, %s)', (username, email, password))
        mysql.connection.commit()
        flash('Registration successful! Please log in.')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/events')
def events():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM events')
    events = cursor.fetchall()
    return render_template('events.html', events=events)

@app.route('/book/<int:event_id>', methods=['GET', 'POST'])
def book(event_id):
    if request.method == 'POST':
        number_of_tickets = int(request.form['tickets'])
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM events WHERE id = %s', (event_id,))
        event = cursor.fetchone()
        if event['available_tickets'] >= number_of_tickets:
            cursor.execute('INSERT INTO bookings (user_id, event_id, number_of_tickets, payment_status) VALUES (%s, %s, %s, %s)',
                           (session['id'], event_id, number_of_tickets, 'Pending'))
            mysql.connection.commit()
            cursor.execute('UPDATE events SET available_tickets = available_tickets - %s WHERE id = %s', (number_of_tickets, event_id))
            mysql.connection.commit()
            return redirect(url_for('payment'))
        else:
            flash('Not enough tickets available')
    return render_template('booking.html', event_id=event_id)

@app.route('/payment', methods=['GET', 'POST'])
def payment():
    if request.method == 'POST':
        # Handle payment logic here
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('UPDATE bookings SET payment_status = %s WHERE user_id = %s AND payment_status = %s',
                       ('Completed', session['id'], 'Pending'))
        mysql.connection.commit()
        flash('Payment successful!')
        return redirect(url_for('events'))
    return render_template('payment.html')

if __name__ == '__main__':
    app.run(debug=True)
