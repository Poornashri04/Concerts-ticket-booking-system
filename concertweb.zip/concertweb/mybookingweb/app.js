const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = 4000;
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.post('/book', (req, res) => {
    const bookingDetails = req.body;
    console.log('Booking details received:', bookingDetails);
    res.send('Booking successful!'); 
});
app.listen(port, () => {
    console.log('Server running at http://localhost:3000');
});

